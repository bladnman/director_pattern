import {escape as esc, WorkspaceClient} from './workspace.js';
import {navigationGraph, navigationRows} from './navigator-graph.js';
const boardURL = (id, from) => `/boards/${encodeURIComponent(id)}/${from ? `?from=${encodeURIComponent(from)}` : ''}`;
export class ProjectNavigator {
  constructor(config, {boardId=null, beforeNavigate=async()=>{}, reveal=null}={}) {
    this.config=config; this.boardId=boardId; this.beforeNavigate=beforeNavigate; this.reveal=reveal;
    this.client=new WorkspaceClient(config); this.expanded=new Set(); this.generation=0;
    this.storageKey=`tinka/${config.workspaceId}/navigator`;
    try { this.saved=JSON.parse(sessionStorage.getItem(this.storageKey)||'{}'); } catch { this.saved={}; }
    this.scope=boardId && ['board','descendants'].includes(this.saved.scope) ? this.saved.scope : 'project';
  }
  mount(anchor) {
    this.button=document.createElement('button'); this.button.id='project-navigator-toggle'; this.button.type='button';
    this.button.className='project-navigator-toggle'; this.button.textContent='Navigator';
    this.button.setAttribute('aria-haspopup','dialog'); this.button.setAttribute('aria-controls','project-navigator'); this.button.setAttribute('aria-expanded','false');
    anchor.before(this.button); this.button.onclick=()=>this.open();
    this.dialog=document.createElement('dialog'); this.dialog.id='project-navigator'; this.dialog.className='project-navigator';
    this.dialog.setAttribute('aria-labelledby','navigator-title');
    this.dialog.innerHTML=`<header class="navigator-head"><div><h2 id="navigator-title">Navigator</h2><p>${esc(this.config.projectLabel)}</p></div><button type="button" data-nav-close aria-label="Close navigator">×</button></header>
      <div class="navigator-find"><label for="navigator-query">Find by name or description</label><input id="navigator-query" type="search" maxlength="2000" placeholder="Search names and descriptions…" autocomplete="off"><label for="navigator-scope" class="sr-only">Search scope</label><select id="navigator-scope"><option value="project">Whole project</option>${this.boardId?'<option value="board">This board</option><option value="descendants">This board and descendants</option>':''}</select></div>
      <p class="navigator-status" role="status" aria-live="polite"></p><div class="navigator-content"></div>`;
    document.body.append(this.dialog);
    this.query=this.dialog.querySelector('input'); this.query.value=this.saved.query||'';
    this.scopeInput=this.dialog.querySelector('select'); this.scopeInput.value=this.scope;
    this.content=this.dialog.querySelector('.navigator-content'); this.status=this.dialog.querySelector('[role=status]');
    this.dialog.querySelector('[data-nav-close]').onclick=()=>this.close();
    this.dialog.addEventListener('cancel',event=>{event.preventDefault();this.close();});
    this.dialog.addEventListener('click',event=>{if(event.target===this.dialog){const r=this.dialog.getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)this.close();}});
    this.dialog.addEventListener('close',()=>{this.dialog.classList.remove('workspace-dialog');this.button.setAttribute('aria-expanded','false');this.button.focus({preventScroll:true});});
    this.query.oninput=()=>{clearTimeout(this.timer);this.generation++;this.persist();this.timer=setTimeout(()=>this.search(),180);};
    this.scopeInput.onchange=()=>{this.scope=this.scopeInput.value;this.persist();this.search();};
    this.content.onclick=event=>{
      const toggle=event.target.closest('[data-nav-expand]');
      if(toggle){const id=toggle.dataset.navExpand;this.expanded.has(id)?this.expanded.delete(id):this.expanded.add(id);this.renderTree();this.content.querySelector(`[data-nav-expand="${CSS.escape(id)}"]`)?.focus({preventScroll:true});return;}
      if(event.target.closest('[data-nav-retry]')){this.open();return;}
      if(event.target.closest('[data-nav-more]')){this.search({more:true});return;}
      const link=event.target.closest('a[data-nav-board]');
      if(link && event.button===0 && !event.metaKey && !event.ctrlKey && !event.shiftKey && !event.altKey){event.preventDefault();this.follow(link).catch(error=>{this.status.textContent=error.message;});}
    };
    this.query.addEventListener('keydown',event=>{if(event.key==='ArrowDown'){const first=this.content.querySelector('a,button');if(first){event.preventDefault();first.focus();}}else if(event.key==='Enter'){event.preventDefault();clearTimeout(this.timer);this.search();}});
    this.dialog.addEventListener('keydown',event=>{if(event.key==='Escape'){event.preventDefault();event.stopImmediatePropagation();this.close();}},true);
    return this;
  }
  persist(){try{sessionStorage.setItem(this.storageKey,JSON.stringify({query:this.query.value,scope:this.scope}));}catch{}}
  close(){clearTimeout(this.timer);this.generation++;this.dialog.close();this.button.focus({preventScroll:true});}
  async open(){
    if(!this.dialog.open){this.dialog.classList.add('workspace-dialog');this.dialog.showModal();}this.button.setAttribute('aria-expanded','true');this.query.focus({preventScroll:true});
    this.status.textContent='Loading project boards…';
    try{
      const [snapshot,catalog]=await Promise.all([this.client.get('/api/workspace?view=graph&covers=0'),this.client.get('/api/boards')]);
      if(!this.dialog.open)return;
      this.graph=navigationGraph(snapshot,(catalog.boards||[]).filter(board=>!(snapshot.boards||[]).some(candidate=>candidate.id===board.id)));
      this.enabled=snapshot.enabled;
      const from=new URLSearchParams(location.search).get('from');
      this.currentPath=(this.graph.parents.get(this.boardId)||[]).includes(from)?[...(this.graph.paths.get(from)||[from]),this.boardId]:this.graph.paths.get(this.boardId);
      for(const id of this.currentPath||[])this.expanded.add(id);
      await this.search();
    }catch(error){this.status.textContent='Project boards could not be loaded.';this.content.innerHTML=`<p class="navigator-empty">${esc(error.message)}</p><button data-nav-retry>Retry</button>`;}
  }
  path(id){return ((id===this.boardId&&this.currentPath)||this.graph.paths.get(id)||[id]).map(id=>this.graph.boards.get(id)?.title||id).join(' / ');}
  renderTree(){
    const {rows,truncated}=navigationRows(this.graph,this.expanded,this.boardId);
    this.status.textContent=`${this.graph.boards.size} ${this.graph.boards.size===1?'board':'boards'} in this project`;
    this.content.innerHTML=`${this.boardId?`<div class="navigator-location"><span>You're here</span><strong>${esc(this.path(this.boardId))}</strong></div>`:''}<h3>Project boards</h3><nav aria-label="Project boards"><ul class="navigator-tree">${rows.map(row=>{
      const board=this.graph.boards.get(row.id),shared=(this.graph.parents.get(row.id)||[]).length>1;
      return `<li style="--nav-depth:${Math.min(row.depth,12)}" ${row.current?'class="navigator-current"':''}>${row.expandable?`<button type="button" data-nav-expand="${esc(row.id)}" aria-expanded="${this.expanded.has(row.id)}" aria-label="${this.expanded.has(row.id)?'Collapse':'Expand'} ${esc(board.title)}">${this.expanded.has(row.id)?'⌄':'›'}</button>`:'<span class="navigator-branch" aria-hidden="true">'+(row.repeated?'↗':'▱')+'</span>'}<a href="${boardURL(row.id,row.parent)}" data-nav-board="${esc(row.id)}" ${row.current?'aria-current="page"':''}><span>${esc(board.title)}</span>${row.current?`<small>Current board${row.repeated?' · Shared reference':''}</small>`:row.repeated?'<small>Shared reference</small>':shared?'<small>Multiple parents</small>':board.legacy?'<small>Legacy board</small>':''}</a></li>`;
    }).join('')}</ul></nav>${truncated?'<p class="navigator-empty">More boards are available. Search by name to find them.</p>':''}${!rows.length?'<p class="navigator-empty">No boards yet.</p>':''}`;
  }
  async search({more=false}={}){
    if(!this.graph)return;
    clearTimeout(this.timer); const token=++this.generation, query=this.query.value.trim();
    if(!query){this.cursor=null;this.results=[];this.renderTree();return;}
    this.status.textContent='Searching…';if(!more){this.results=[];this.content.innerHTML='';}
    const params=new URLSearchParams({query,kind:'all',sort:'title',direction:'asc',limit:'40'});
    if(this.boardId&&this.scope!=='project'){params.set('withinBoardId',this.boardId);params.set('recursive',String(this.scope==='descendants'));}
    if(more&&this.cursor)params.set('cursor',this.cursor);
    try{
      const data=this.enabled?await this.client.get(`/api/search?${params}`):{results:[],nextCursor:null};
      if(token!==this.generation||!this.dialog.open)return;
      this.results.push(...data.results);this.cursor=data.nextCursor;
      const legacy=[...this.graph.boards.values()].filter(board=>board.legacy&&board.title.toLowerCase().includes(query.toLowerCase())&&(this.scope==='project'||board.id===this.boardId));
      const boardMatches=new Set(this.results.filter(row=>row.type==='board').map(row=>row.id));
      const results=[...this.results.filter(row=>!(row.type==='item'&&row.kind==='board'&&boardMatches.has(row.childBoardId))),...legacy.map(board=>({...board,type:'board',legacy:true}))];
      this.status.textContent=`${results.length}${this.cursor?'+':''} ${results.length===1?'match':'matches'} · ${this.scopeInput.selectedOptions[0].textContent}`;
      this.content.innerHTML=results.map(row=>this.resultMarkup(row)).join('')+(!results.length?`<p class="navigator-empty">No matches for “${esc(query)}”. ${this.scope!=='project'?'Try Whole project or a different name.':'Try a different name or description.'}</p>`:'')+(this.cursor?'<button type="button" class="navigator-more" data-nav-more>Load more results</button>':'')+(!this.enabled?'<p class="navigator-empty">Search includes legacy board names. Open a board to explore its experiments.</p>':'');
    }catch(error){if(token!==this.generation)return;this.status.textContent='Search could not finish.';this.content.innerHTML=`<p class="navigator-empty">${esc(error.message)}</p><button data-nav-retry>Retry search</button>`;}
  }
  resultMarkup(row){
    const board=row.type==='board', locations=(row.locations||[]).filter(location=>!location.archived);
    const inScope=location=>this.scope==='project'||location.boardId===this.boardId||this.graph.paths.get(location.boardId)?.includes(this.boardId);
    const ordered=[...locations.filter(inScope),...locations.filter(location=>!inScope(location))];
    const seen=new Set(),links=ordered.filter(location=>{if(seen.has(location.boardId))return false;seen.add(location.boardId);return true;});
    const locationMarkup=board?`<a href="${boardURL(row.id)}" data-nav-board="${esc(row.id)}">${esc(this.path(row.id))}</a>`:links.map(location=>`<a href="${boardURL(location.boardId)}?reveal=${encodeURIComponent(location.placementId)}" data-nav-board="${esc(location.boardId)}" data-nav-placement="${esc(location.placementId)}">${esc(this.path(location.boardId))}</a>`).join('');
    return `<article class="navigator-result"><div class="navigator-result-kind">${esc(board?'Board':row.kind||'Idea')}</div><h3>${esc(row.title)}</h3>${row.description?`<p>${esc(row.description)}</p>`:''}<div class="navigator-result-locations">${locationMarkup||`<a href="${row.childBoardId?boardURL(row.childBoardId):`/app/item.html?item=${encodeURIComponent(row.id)}`}" ${row.childBoardId?`data-nav-board="${esc(row.childBoardId)}"`:''}>${row.childBoardId?'Open board':'Open item (not placed on an active board)'}</a>`}</div>${row.locationCount>locations.length?`<small>${row.locationCount} saved locations; active locations shown when available.</small>`:''}${row.legacy?'<small>Legacy board · search covers its name</small>':''}</article>`;
  }
  async follow(link){
    await this.beforeNavigate();
    if(link.dataset.navBoard===this.boardId){this.close();if(link.dataset.navPlacement&&this.reveal)await this.reveal(link.dataset.navPlacement);return;}
    this.close();location.assign(link.href);
  }
}
