import { watchBoard } from './live.js';
import { reconcileChildren } from './reconcile.js';
import { openRemovalPrompt } from './agent-prompt.js';
import { WorkspaceBoard } from './workspace-board.js';
import { contentURL, enableOrganization } from './workspace.js';
import { validTextAnchor } from './markdown-document.js';
import {bindCommitShortcut,commitShortcutLabel} from './interaction.js';

const $ = id => document.getElementById(id);
const viewport = $('viewport');
const world = $('world');
const plane = $('plane');
const dialog = $('reader-dialog');
const slider = $('zoom-slider');
const track = $('dot-track');
const tooltip = $('dot-tooltip');
const sizeMenu = $('size-menu');
const geometry = { pad: 70, gap: 68, cardWidth: 1000, rowHeight: 1220 };
const MIN_ZOOM = .05;
const MAX_ZOOM = 1.25;
const SIZE_NAMES = { fit: 'Fit', custom: 'Custom', compact: 'Compact', standard: 'Standard', wide: 'Wide' };
const boardMatch = location.pathname.match(/^\/boards\/([a-z0-9][a-z0-9-]*)\/?$/);
const boardId = boardMatch?.[1];
const boardApi = `/api/boards/${encodeURIComponent(boardId || '')}`;
let notesKey, viewKey, workspaceId;
const esc = value => String(value ?? '').replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]);
const clampZoom = value => Math.max(MIN_ZOOM, Math.min(MAX_ZOOM, value));

let board = null;
let graph = null;
let appTitle = 'Tinka';
let appConfig;
let rounds = [];
let revisions = {};
let all = [];
let currentRound = 0;
let zoom = .5;
let notes = {};
let active = null;
let activeVariantId = 'original';
let activeRevision = null;
let liveSnapshot = null;
let saveTimer;
let saveSequence = 0;
let saveQueue = Promise.resolve();
let shellReloadTimer;
let routedHash = null;
let notesOpen = false;
let dotSignature = '';
let scrub = null;
let noteFieldKey = null;
const readerView = { size: 'fit', theme: 'paper', type: 100 };
const loadedPreviews = new Map();

function safeBoardPath(path) {
  if (typeof path !== 'string') return null;
  const parts = path.split('/');
  if (!parts.length || parts.some(part => !part || part === '.' || part === '..' || part.includes('\\') || part.includes('\0'))) return null;
  return `/boards/${encodeURIComponent(boardId)}/files/${parts.map(encodeURIComponent).join('/')}`;
}

function safeRemoteUrl(value) {
  if (!value) return null;
  try {
    const url = new URL(value);
    return ['http:', 'https:'].includes(url.protocol) ? url.href : null;
  } catch { return null; }
}

function descriptor(concept, variant = null) {
  if (concept?.graphItem) return { kind: variant?.content?.kind || variant?.kind || concept.graphItem.content?.kind || 'text', name: variant ? `${concept.name} · ${variant.name}` : concept.name, graphItem: concept.graphItem, graphRevision: variant };
  return {
    kind: variant?.kind || concept.kind || 'html',
    path: variant?.path || concept.path || `rounds/${concept.round}/${concept.id}/index.html`,
    url: variant ? variant.url || null : concept.url || null,
    name: variant ? `${concept.name} · ${variant.name}` : concept.name,
  };
}

function standaloneHref(concept, variant = null) {
  if (concept?.graphItem) return contentURL(concept.graphItem, variant);
  const item = descriptor(concept, variant);
  return safeRemoteUrl(item.url) || safeBoardPath(item.path);
}

function mediaHref(item, theme = 'paper', scale = 100, inReader = false) {
  const params = new URLSearchParams({ board: boardId, kind: item.kind, name: item.name, theme, scale: String(scale) });
  if (item.url) params.set('url', item.url);
  else params.set('path', item.path);
  // The experiment view already names the item and links to it; its media page needs no header of its own.
  if (inReader) params.set('chrome', 'none');
  return `/app/media.html?${params}`;
}

function previewHref(concept, variant = null, theme = 'paper', scale = 100, revision = null, inReader = false) {
  if (concept?.graphItem) { const params = new URLSearchParams({item:concept.graphItem.id,theme,scale:String(scale),commentBoard:boardId}); if (variant) params.set('variant',variant.id); if (revision) params.set('v',String(revision)); return `/app/item.html?${params}`; }
  const item = descriptor(concept, variant);
  const remote = safeRemoteUrl(item.url);
  const source = safeBoardPath(item.path);
  const href = item.kind === 'html' && !remote && source ? source : mediaHref({ ...item, url: remote }, theme, scale, inReader);
  const url = new URL(href, location.href);
  if (item.kind === 'html' && !remote) { url.searchParams.set('theme', theme); url.searchParams.set('scale', String(scale)); }
  if (revision) url.searchParams.set('v', revision);
  return url.href;
}

// Assigning a frame's src adds an entry to the tab's session history, so browser Back would step inside the
// frame. Replacing the frame's location keeps Back and Forward for Tinka's own places.
function replaceFrame(frame, url) {
  try { if (frame.contentWindow) { frame.contentWindow.location.replace(url); return; } } catch {}
  frame.src = url;
}

function readRound() {
  all = rounds.flatMap((round, row) => (round.concepts || []).map((concept, col) => ({ ...concept, round: round.id, row, col, key: concept.key || `${round.id}/${concept.id}` })));
  if (graph) { const order=graph.snapshot.reviewOrder;all.sort((a,b)=>order.indexOf(a.placement.id)-order.indexOf(b.placement.id)); }
}

async function fetchBoard() {
  const response = await fetch(boardApi, { cache: 'no-store' });
  if (!response.ok) throw new Error(`Board metadata unavailable (${response.status})`);
  const data = await response.json();
  if (data.schemaVersion === 2) {
    if (!graph) graph = new WorkspaceBoard(appConfig, data, { concepts:()=>all, active:()=>active, zoom:()=>zoom, shiftOrigin:(dx,dy)=>{if(dx||dy){view.x-=dx*zoom;view.y-=dy*zoom;resting=false;}}, shiftViewport:(dx,dy)=>{if(dx||dy)moveView(view.x+dx,view.y+dy);}, revealPlacements:revealPlacements, preview:c=>previewHref(c), layout:()=>{ if(resting)rest();else applyView(); }, mode:mode=>{ if(mode==='canvas'){zoom=1;settleCushion();}else{viewport.scrollLeft=0;viewport.scrollTop=0;} }, reloadReader:()=>loadRevision(), saveStatus:setSaveStatus, openOwner:()=>{const c=graph.ownerConcept();if(c)openReader(c.key);}, closeReader:()=>closeReader(), flushNotes:flushNoteEdits, liveReady:()=>{void drainLiveUpdates().catch(()=>{});}, data:acceptGraphData });
    return graph.adapt(data);
  }
  if (!Array.isArray(data.rounds)) throw new Error('The board manifest is invalid.');
  return data;
}

async function loadAppTitle() {
  const response = await fetch('/api/config', { cache: 'no-store' });
  if (!response.ok) throw new Error('Workspace identity unavailable. Reload when the server is ready.');
  const config = await response.json();
  if (!config.workspaceId || !config.projectLabel) throw new Error('Workspace identity unavailable.');
  appConfig = config;
  workspaceId = config.workspaceId;
  appTitle = `Tinka / ${config.projectLabel}`;
  const prefix = `tinka/${config.workspaceId}/${boardId}`;
  notesKey = `${prefix}/notes`;
  viewKey = `${prefix}/view`;
  $('project-label').textContent = 'Home';
  $('reader-project').textContent = 'Home';
  document.querySelectorAll('.brand').forEach(brand => { brand.setAttribute('aria-label', `${appTitle} home`); brand.title = `${appTitle} · all boards`; });
  if (board) updateMetadata();
}

function updateMetadata() {
  const title = board.title || 'Untitled board';
  document.title = active && dialog.open ? `${appTitle} / ${title} / ${descriptor(active, currentVariant()).name}` : `${appTitle} / ${title}`;
  $('board-title').textContent = title;
  $('board-title').title = title;
  $('reader-board-link').textContent = '← Board';
  $('reader-board-link').title = `Return to ${title}`;
  $('reader-board-link').setAttribute('aria-label', `Back to board ${title}`);
  $('board-description').textContent = board.description || 'Working experiments and the questions they invite.';
  $('experiment-count').textContent = `${all.length} ${all.length === 1 ? 'experiment' : 'experiments'}`;
  $('round-count').textContent = `${rounds.length} ${rounds.length === 1 ? 'exploration' : 'explorations'}`;
}

function buildCanvas() {
  if (graph) { graph.build(all); wireReaderReview(); updateMetadata(); renderNav(); applyNotes(); return; }
  const retainedLegacy=new Map([...world.querySelectorAll(".concept-card")].map(card=>[card.dataset.key,card.querySelector("iframe")]));
  const cards = round => all.filter(concept => concept.round === round.id).map(concept => {
    const versions = revisions[concept.key] || [];
    const revisionButtons = versions.map(variant => `<button class="revision-button" type="button" data-open="${esc(concept.key)}" data-revision="${esc(variant.id)}">Try ${esc(variant.name)} ↗</button>`).join('');
    const handoff = safeBoardPath(concept.handoff);
    const previewSource=previewHref(concept,null,concept.tone==='night'?'night':'paper');
    const retained=retainedLegacy.get(concept.key);
    const preview=retained?.dataset.previewSource===previewSource?retained.src:previewSource;
    return `<article class="concept-card" data-key="${esc(concept.key)}" data-placement="${esc(concept.key)}"><header class="card-label"><div class="card-title"><span class="card-number">${esc(concept.number || String(concept.col + 1).padStart(2, '0'))}</span><h3>${esc(concept.name)}</h3><span class="card-category">${esc(concept.category || '')}</span></div><div class="card-actions">${revisionButtons}<button type="button" data-open="${esc(concept.key)}">Open experiment ↗</button>${handoff ? `<a class="handoff-link" href="${esc(handoff)}" target="_blank" rel="noopener">Handoff ↗</a>` : ''}<button class="remove-action" type="button" data-remove-experiment="${esc(concept.key)}" aria-label="Remove ${esc(concept.name)} from board" title="Get a removal prompt">Remove…</button></div></header><div class="preview"><iframe src="${esc(preview)}" data-preview-source="${esc(previewSource)}" title="${esc(concept.name)} preview" tabindex="-1" loading="eager" inert></iframe><button class="preview-launch" type="button" data-open="${esc(concept.key)}" aria-label="Explore ${esc(concept.name)}"><span>Open ${esc(concept.name)} ↗</span></button></div><div class="card-copy"><div><p>${esc(concept.description || '')}</p><p class="question">${esc(concept.question || '')}</p></div><div class="note-box"><button class="shortlist" type="button" data-star="${esc(concept.key)}" aria-label="Shortlist ${esc(concept.name)}" aria-pressed="false">☆</button><label>Thoughts to return to · ${esc(commitShortcutLabel())} to save<textarea aria-keyshortcuts="Meta+Enter Control+Enter" data-note="${esc(concept.key)}" placeholder="What feels right? What gets in the way?" aria-label="Notes on ${esc(concept.name)}"></textarea></label></div></div></article>`;
  }).join('');
  const freshLegacy=document.createElement("template");
  freshLegacy.innerHTML = rounds.map(round => `<section class="round" data-round="${esc(round.id)}" aria-labelledby="round-heading-${esc(round.id)}"><header class="round-header"><span class="round-label">ROUND ${esc(round.number || '')} · ${esc(round.date || '')}</span><h2 id="round-heading-${esc(round.id)}">${esc(round.title || 'Exploration')}</h2><p>${esc(round.description || '')}</p></header><div class="concepts">${cards(round)}</div></section>`).join('') + '<section class="future-row"><span>CONTINUE EXPLORING</span><h2>Room for what comes next.</h2><p>New explorations can join this board without replacing earlier work.</p></section>';
  reconcileChildren(world,freshLegacy.content);
  decorateBuildCards();
  renderNav();
  if (resting) rest(); else applyView();
  updateMetadata();
}

function renderNav() {
  const round = rounds[currentRound];
  $('round-status').textContent = round ? `Round ${round.number || currentRound + 1} / ${round.date || round.id}` : 'No explorations yet';
}

// ---- Board canvas: an endless plane. The plane carries the pan and the world the zoom; nothing scrolls natively. ----
// The board can move past any edge until only KEEP pixels of it are left in view.
const KEEP = 80;
// An invisible margin lets the browser scroll the canvas in any direction to reveal a focused control or a
// find-in-page match. The scroll is turned straight into a pan, so the view has no edges of its own.
const CUSHION = 100000;
const view = { x: 0, y: 0 };
// At rest the view shows the board's resting place and follows window resizes; any pan or zoom ends that.
let resting = true;
let glide = 0;
let glideTarget = null;
let roundFrame = 0;

function settleCushion() {
  if (graph?.mode === 'grid') return;
  viewport.scrollLeft = CUSHION;
  viewport.scrollTop = CUSHION;
}

function clampView({ x, y }) {
  const pad = geometry.pad * zoom;
  const width = Math.max(0, world.offsetWidth * zoom - pad * 2);
  const height = Math.max(0, world.offsetHeight * zoom - pad * 2);
  const keepX = Math.min(KEEP, viewport.clientWidth / 3, width);
  const keepY = Math.min(KEEP, viewport.clientHeight / 3, height);
  return {
    x: Math.min(viewport.clientWidth - keepX - pad, Math.max(keepX - width - pad, x)),
    y: Math.min(viewport.clientHeight - keepY - pad, Math.max(keepY - height - pad, y)),
  };
}

function applyView() {
  if (graph?.mode === 'grid') { plane.style.transform='none'; world.style.transform='none'; return; }
  Object.assign(view, clampView(view));
  plane.style.transform = `translate(${Math.round(view.x)}px, ${Math.round(view.y)}px)`;
  world.style.transform = `scale(${zoom})`;
  const percent = Math.round(zoom * 100);
  slider.value = String(percent);
  slider.setAttribute('aria-valuetext', `${percent} percent`);
  slider.title = `Zoom ${percent}%`;
}

// A board rests centred on each axis where it fits, otherwise at its left edge with the given exploration on top.
function restingView(row = currentRound) {
  const width = world.offsetWidth * zoom;
  const height = world.offsetHeight * zoom;
  return {
    x: width <= viewport.clientWidth ? Math.floor((viewport.clientWidth - width) / 2) : 0,
    y: rounds.length && height <= viewport.clientHeight ? Math.floor((viewport.clientHeight - height) / 2) : -row * geometry.rowHeight * zoom,
  };
}

function stopGlide() {
  cancelAnimationFrame(glide);
  glide = 0;
  glideTarget = null;
}

function rest() {
  if (graph?.mode === 'grid') { applyView(); return; }
  stopGlide();
  resting = true;
  Object.assign(view, restingView());
  applyView();
}

// The reader's own pan or zoom: the quiet round status follows it.
function moveView(x, y) {
  stopGlide();
  resting = false;
  view.x = x;
  view.y = y;
  applyView();
  trackRound();
}

// Ease to a place (instantly with reduced motion). A placement chosen by the app sets the round itself.
function glideTo(target, { track = false } = {}) {
  stopGlide();
  resting = false;
  if (!track) { cancelAnimationFrame(roundFrame); roundFrame = 0; }
  const to = clampView(target);
  const from = { ...view };
  const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const start = performance.now();
  const step = now => {
    const t = reduced ? 1 : Math.min(1, (now - start) / 240);
    const eased = 1 - (1 - t) ** 3;
    view.x = from.x + (to.x - from.x) * eased;
    view.y = from.y + (to.y - from.y) * eased;
    applyView();
    if (track) trackRound();
    glide = t < 1 ? requestAnimationFrame(step) : 0;
    if (!glide) glideTarget = null;
  };
  if (reduced) { step(start); return; }
  glideTarget = to;
  glide = requestAnimationFrame(step);
}

function trackRound() {
  if (roundFrame) return;
  roundFrame = requestAnimationFrame(() => {
    roundFrame = 0;
    if (!rounds.length) return;
    const row = Math.max(0, Math.min(rounds.length - 1, Math.floor((-view.y / zoom + 130) / geometry.rowHeight)));
    if (row !== currentRound) { currentRound = row; renderNav(); }
  });
}

function changeZoom(value, cx = viewport.clientWidth / 2, cy = viewport.clientHeight / 2) {
  const scale = clampZoom(value) / zoom;
  zoom = clampZoom(value);
  moveView(cx - (cx - view.x) * scale, cy - (cy - view.y) * scale);
}

// Reveal one newly pasted group, keeping the normal zoom whenever it fits.
function revealPlacements(placements) {
  if (graph?.mode === 'grid' || !placements.length) return;
  const x = Math.min(...placements.map(p=>p.x)), y = Math.min(...placements.map(p=>p.y));
  const width = Math.max(...placements.map(p=>p.x+p.width)) - x;
  const height = Math.max(...placements.map(p=>p.y+p.height)) - y;
  const margin = 24;
  const fit = Math.min((viewport.clientWidth-margin*2)/width,(viewport.clientHeight-margin*2)/height);
  if (fit < zoom) changeZoom(fit);
  const region = viewport.getBoundingClientRect(), rect = world.getBoundingClientRect();
  const left = rect.left + (x + graph.origin.x)*zoom, top = rect.top + (y + graph.origin.y)*zoom;
  const visibleX = Math.max(region.left+margin,Math.min(left,region.right-margin-width*zoom));
  const visibleY = Math.max(region.top+margin,Math.min(top,region.bottom-margin-height*zoom));
  const dx = visibleX-left, dy = visibleY-top;
  if (Math.abs(dx)>.5 || Math.abs(dy)>.5) moveView(view.x+dx,view.y+dy);
}

// Fit every exploration on both axes, centred.
function fitBoard() {
  if (graph?.mode === 'grid') { viewport.scrollTo({top:0,left:0}); return; }
  const margin = 24;
  const contentWidth = world.offsetWidth - geometry.pad * 2;
  const contentHeight = world.offsetHeight - geometry.pad * 2;
  if (contentWidth <= 0 || contentHeight <= 0) return;
  zoom = clampZoom(Math.min((viewport.clientWidth - margin * 2) / contentWidth, (viewport.clientHeight - margin * 2) / contentHeight));
  const pad = geometry.pad * zoom;
  moveView((viewport.clientWidth - contentWidth * zoom) / 2 - pad, (viewport.clientHeight - contentHeight * zoom) / 2 - pad);
}

function jump(key) {
  if (graph?.mode === 'grid') return;
  const concept = all.find(item => item.key === key) || graph?.ownerConcept(key) || graph?.aliasConcept(key);
  if (!concept) return;
  if (currentRound !== concept.row) { currentRound = concept.row; renderNav(); }
  if (zoom < .4) { view.x *= .5 / zoom; view.y *= .5 / zoom; zoom = .5; }
  viewport.focus({ preventScroll: true });
  const place = restingView(concept.row);
  const wide = world.offsetWidth * zoom > viewport.clientWidth;
  glideTo({ x: wide ? 25 - (geometry.pad + concept.col * (geometry.cardWidth + geometry.gap)) * zoom : place.x, y: place.y });
}

function showRow(row) {
  currentRound = row;
  renderNav();
  const first = all.find(item => item.row === row);
  if (first) jump(first.key);
  else glideTo(restingView(row));
}

function viewportPoint(clientX, clientY) {
  const rect = viewport.getBoundingClientRect();
  return [clientX - rect.left, clientY - rect.top];
}

// ---- Browser history: each place-changing navigation is one real entry. ----
function decodeHash(hash) {
  try { return decodeURIComponent(String(hash || '').replace(/^#/, '')); } catch { return null; }
}

function parseHash(hash = location.hash) {
  const raw = decodeHash(hash);
  if (!raw) return { view: 'board', round: null, invalid: raw === null };
  const row = rounds.findIndex(round => raw === `round-${round.id}`);
  if (row >= 0) return { view: 'board', round: rounds[row].id };
  let [key, revision] = raw.split('~');
  if (graph) { const alias=graph.aliasConcept(key)||graph.ownerConcept(key);if(alias){key=alias.key;revisions[key]=graph.revisionsFor(alias.graphItem);} }
  if (all.some(concept => concept.key === key) || graph?.ownerConcept(key) || graph?.aliasConcept(key)) return { view: 'experiment', key, revision: (revisions[key] || []).some(variant => variant.id === revision) ? revision : null };
  return { view: 'board', round: null, invalid: true };
}

function hashFor(state) {
  if (state.view === 'experiment') return `#${state.key}${state.revision ? `~${state.revision}` : ''}`;
  return state.round ? `#round-${state.round}` : '';
}

function commitHistory(state, mode) {
  if (mode !== 'push' && mode !== 'replace') return;
  const hash = hashFor(state);
  if (decodeHash(location.hash) === decodeHash(hash) && (mode === 'push' || location.hash === hash)) return;
  const url = `${location.pathname}${location.search}${hash}`;
  if (mode === 'push') history.pushState(null, '', url);
  else history.replaceState(history.state, '', url);
  routedHash = location.hash;
}

function readerState() {
  return { view: 'experiment', key: active.key, revision: activeVariantId === 'original' ? null : activeVariantId };
}

// Back and Forward render the state in the URL; they never add entries of their own.
function route() {
  if (!board || location.hash === routedHash) return;
  const state = parseHash();
  if (state.invalid) commitHistory({ view: 'board', round: null }, 'replace');
  routedHash = location.hash;
  if (state.view === 'experiment') { openReader(state.key, state.revision || 'original', { history: 'replace' }); return; }
  if (dialog.open || active) { closeReader({ history: 'none' }); return; }
  const row = rounds.findIndex(round => round.id === state.round);
  if (row >= 0) showRow(row);
}

// ---- Experiment view ----
function currentVariant() { return (revisions[active?.key] || []).find(variant => variant.id === activeVariantId) || null; }
function activeSourceKey() {
  if (!active) return null;
  const variant = currentVariant();
  const parts = variant?.path?.split('/') || [];
  const sourceKey = parts[0] === 'rounds' && parts.length > 2 ? `${parts[1]}/${parts[2]}` : active.key;
  return liveSnapshot?.concepts?.[sourceKey] ? sourceKey : active.key;
}

function focusReader() {
  if (dialog.open) $('active-reader').focus({ preventScroll: true });
}

function sendPreferences() {
  $('active-reader').contentWindow?.postMessage({ type: 'reader-preferences', theme: readerView.theme, scale: readerView.type }, location.origin);
}

function renderSizeControls(layout = true) {
  const viewer = $('reader-window');
  const size = readerView.size;
  const customText = `${Math.round(viewer.offsetWidth)} × ${Math.round(viewer.offsetHeight)}`;
  const variant = currentVariant();
  const label = `Window size: ${SIZE_NAMES[size]}${size === 'custom' ? ` ${customText}` : ''}${variant ? `. Version: ${variant.name}` : ''}`;
  $('size-value').textContent = SIZE_NAMES[size];
  $('size-trigger').setAttribute('aria-label', label);
  $('size-trigger').title = (revisions[active?.key] || []).length ? `${label} · choose a window size or version` : label;
  $('reader-fit').setAttribute('aria-pressed', String(size === 'fit'));
  sizeMenu.querySelectorAll('[data-size]').forEach(button => button.setAttribute('aria-pressed', String(button.dataset.size === size)));
  sizeMenu.querySelector('[data-size="custom"]').hidden = size !== 'custom';
  $('custom-size').textContent = customText;
  if (layout) layoutReaderFooter();
}

function setReaderSize(size) {
  const viewer = $('reader-window');
  readerView.size = SIZE_NAMES[size] ? size : 'fit';
  if (readerView.size !== 'custom') {
    viewer.style.removeProperty('width');
    viewer.style.removeProperty('height');
    viewer.dataset.size = readerView.size;
  }
  renderSizeControls();
}

function setTheme(theme, send = true) {
  readerView.theme = theme === 'night' ? 'night' : 'paper';
  const night = readerView.theme === 'night';
  $('reader-theme').setAttribute('aria-pressed', String(night));
  $('reader-theme').title = night ? 'Light: Night · switch to Paper' : 'Light: Paper · switch to Night';
  if (send) sendPreferences();
}

function setType(value, send = true) {
  readerView.type = [100, 115, 130].includes(Number(value)) ? Number(value) : 100;
  const input = $('reader-type');
  input.value = String(readerView.type);
  input.setAttribute('aria-valuetext', `${readerView.type}%`);
  input.title = `Type size ${readerView.type}%`;
  if (send) sendPreferences();
}

function openSizeMenu() {
  sizeMenu.hidden = false;
  $('size-trigger').setAttribute('aria-expanded', 'true');
  (sizeMenu.querySelector('button[aria-pressed="true"]:not([hidden])') || sizeMenu.querySelector('button:not([hidden])')).focus({ preventScroll: true });
}

function closeSizeMenu(refocus = true) {
  if (sizeMenu.hidden) return;
  sizeMenu.hidden = true;
  $('size-trigger').setAttribute('aria-expanded', 'false');
  if (refocus) $('size-trigger').focus({ preventScroll: true });
}

function renderRevisionOptions() {
  const versions = revisions[active?.key] || [];
  $('revision-group').hidden = !versions.length;
  $('revision-options').innerHTML = versions.length ? [{ id: 'original', name: 'Original' }, ...versions].map(variant => `<button type="button" data-revision-choice="${esc(variant.id)}" aria-pressed="${variant.id === activeVariantId}"><span>${esc(variant.name)}</span></button>`).join('') : '';
}

function setNotesOpen(open, { focus = true } = {}) {
  notesOpen = open;
  $('notes-panel').hidden = !open;
  $('notes-toggle').setAttribute('aria-expanded', String(open));
  if (focus) (open ? $('reader-note') : $('notes-toggle')).focus({ preventScroll: true });
}

function syncReaderNotes() {
  if (!active) return;
  const note = notes[active.key]?.note || '';
  const field = $('reader-note');
  // Always follow a change of experiment, even mid-typing; otherwise keep the caret where the user is typing.
  if (noteFieldKey !== active.key || (field.value !== note && document.activeElement !== field)) { field.value = note; noteFieldKey = active.key; }
  const hasNote = Boolean(note.trim());
  document.querySelector('.note-dot').hidden = !hasNote;
  $('notes-toggle').setAttribute('aria-label', hasNote ? 'Notes (this experiment has a note)' : 'Notes');
  const starred = Boolean(notes[active.key]?.star);
  $('reader-star').title = starred ? 'Shortlisted · remove from shortlist' : 'Add to shortlist';
  layoutReaderHeader();
}

function renderReaderHeader() {
  if (!active) return;
  const variant = currentVariant();
  const round = rounds[active.row];
  const name = descriptor(active, variant).name;
  const hint = variant?.hint || active.hint || '';
  $('reader-name').textContent = name;
  $('reader-name').title = hint ? `${name} · ${hint}` : name;
  $('reader-star').dataset.star = active.key;
  $('reader-star').setAttribute('aria-label', `Shortlist ${active.name}`);
  $('reader-note').setAttribute('aria-label', `Notes on ${active.name}`);
  $('notes-for').textContent = `Round ${round?.number || active.row + 1} · ${active.number ? `${active.number} ` : ''}${name}`;
  $('reader-hint').textContent = hint;
  $('reader-board-link').href = `${location.pathname}${location.search}${rounds[currentRound] ? `#round-${rounds[currentRound].id}` : ''}`;
  applyNotes();
  if (graph) graph.reader(active);
}

function loadRevision({ focus = true } = {}) {
  if (!active) return;
  const variant = currentVariant();
  $('active-reader').title = `${descriptor(active, variant).name} experiment`;
  const standalone = standaloneHref(active, variant);
  $('reader-standalone').hidden = !standalone;
  if (standalone) $('reader-standalone').href = standalone;
  activeRevision = liveSnapshot?.concepts?.[activeSourceKey()]?.revision || null;
  $('reader-update').hidden = true;
  layoutReaderHeader();
  replaceFrame($('active-reader'), previewHref(active, variant, readerView.theme, readerView.type, activeRevision || 'initial', true));
  if (focus) focusReader();
}

function readerSequence() {
  if (graph) return all.filter(c=>c.key===active?.key||!['reserved','building'].includes(c.graphItem?.build?.state));
  return all.filter(concept => concept.key === active?.key || !['reserved', 'building'].includes(liveSnapshot?.concepts?.[concept.key]?.state));
}

function dotLabel(concept, index, total) {
  const round = rounds[concept.row];
  return `${index + 1} of ${total}: Round ${round?.number || concept.row + 1} · ${concept.number ? `${concept.number} ` : ''}${concept.name}`;
}

// Keep the current dot centred in the strip (the browser clamps at either end).
function revealDot(dot) {
  if (!dot || scrub) return;
  track.scrollLeft = dot.offsetLeft - track.offsetLeft + dot.offsetWidth / 2 - track.clientWidth / 2;
  updateTrackFade();
}

function renderDots(sequence, index) {
  const signature = sequence.map(concept => `${concept.key}\u0000${concept.name}\u0000${concept.row}`).join('\u0001');
  const focusedDot = track.contains(document.activeElement);
  if (signature !== dotSignature) {
    dotSignature = signature;
    track.innerHTML = sequence.map((concept, i) => `<button type="button" class="experiment-dot${i === 0 || concept.row !== sequence[i - 1].row ? ' group-start' : ''}" data-dot="${esc(concept.key)}" aria-label="${esc(dotLabel(concept, i, sequence.length))}" aria-pressed="false" tabindex="-1"></button>`).join('');
  }
  let current = null;
  track.querySelectorAll('[data-dot]').forEach(dot => {
    const selected = dot.dataset.dot === active?.key;
    dot.setAttribute('aria-pressed', String(selected));
    dot.tabIndex = selected ? 0 : -1;
    if (selected) current = dot;
  });
  track.setAttribute('aria-label', index < 0 ? 'Experiments on this board' : `Experiments on this board, ${index + 1} of ${sequence.length}`);
  revealDot(current);
  if (focusedDot && current && document.activeElement !== current) current.focus({ preventScroll: true });
}

// Names wrap naturally; navigation remains short and the current item is the only title.
const readerHeader = document.querySelector('.reader-header');
function layoutReaderHeader() {
  readerHeader.dataset.layout = 'quiet';
}

function layoutReaderChrome() {
  layoutReaderHeader();
  layoutReaderFooter();
}

// The footer is always one row. Its dot strip shows up to 9 dots and the arrows hug it. As room runs out, measured
// against the actual widths: the strip drops to 7, 5, then 3 dots; Back becomes a board glyph with "Board"; the
// view controls fold into a View popover; the View button drops its word; and only then does Back drop its word
// (the strip may grow again each time room is freed). The navigation stays centred on the page when it can,
// otherwise between its neighbours.
const readerFooter = document.querySelector('.reader-footer');
const STRIP_DOTS = [9, 7, 5, 3];
const DOT_WIDTH = 24;
const FOOTER_STEPS = [['full', 'folded'], ['board', 'folded'], ['board', 'folded-icon'], ['icon', 'folded-icon']];
function layoutReaderFooter() {
  if (!dialog.open) return;
  const nav = readerFooter.querySelector('.experiment-navigation');
  const tools = readerFooter.querySelector('.reader-tools');
  readerFooter.style.setProperty('--nav-shift', '0px');
  const navGap = parseFloat(getComputedStyle(nav).columnGap) || 0;
  const arrows = $('reader-previous').offsetWidth + $('reader-next').offsetWidth + 2 * navGap;
  const dots = track.scrollWidth;
  const room = () => {
    const gap = parseFloat(getComputedStyle(readerFooter).columnGap) || 0;
    const start = $('close-reader').getBoundingClientRect().right + gap;
    return { start, end: tools.getBoundingClientRect().left - gap };
  };
  let strip = STRIP_DOTS.at(-1);
  for (const [back, view] of FOOTER_STEPS) {
    readerFooter.dataset.back = back;
    readerFooter.dataset.tools = view;
    const { start, end } = room();
    const fit = STRIP_DOTS.find(count => arrows + Math.min(dots, count * DOT_WIDTH) <= end - start + .5);
    if (fit) { strip = fit; break; }
  }
  readerFooter.style.setProperty('--strip-dots', String(strip));
  if (readerFooter.dataset.tools === 'inline') setViewOpen(false, { focus: false });
  const box = readerFooter.getBoundingClientRect();
  const { start, end } = room();
  const slack = Math.max(0, (end - start - nav.getBoundingClientRect().width) / 2);
  const shift = Math.max(-slack, Math.min(slack, box.left + box.width / 2 - (start + end) / 2));
  readerFooter.style.setProperty('--nav-shift', `${Math.round(shift)}px`);
  revealDot(track.querySelector('[aria-pressed="true"]'));
  updateTrackFade();
}

// Fade an edge of the strip while more dots lie beyond it.
function updateTrackFade() {
  const more = track.scrollWidth - track.clientWidth;
  track.style.setProperty('--fade-start', track.scrollLeft > 1 ? '16px' : '0px');
  track.style.setProperty('--fade-end', track.scrollLeft < more - 1 ? '16px' : '0px');
}

// ---- View popover: the folded home of the view controls on narrow footers ----
const viewControls = $('view-controls');
function setViewOpen(open, { focus = true } = {}) {
  const wasOpen = viewControls.classList.contains('open');
  if (open === wasOpen) return;
  viewControls.classList.toggle('open', open);
  $('view-toggle').setAttribute('aria-expanded', String(open));
  if (!open) closeSizeMenu(false);
  if (focus) (open ? $('reader-type') : $('view-toggle')).focus({ preventScroll: true });
}

function updateReaderNavigation() {
  const sequence = readerSequence();
  const index = sequence.findIndex(concept => concept.key === active?.key);
  $('reader-position').textContent = index < 0 ? '' : `Experiment ${index + 1} of ${sequence.length}: ${active.name}`;
  track.dataset.position = index < 0 ? '' : `${index + 1} / ${sequence.length}`;
  for (const [id, offset, label] of [['reader-previous', -1, 'Previous'], ['reader-next', 1, 'Next']]) {
    const neighbor = index < 0 ? null : sequence[index + offset];
    const button = $(id);
    button.disabled = !neighbor;
    button.title = neighbor ? `${label}: ${neighbor.name}` : `No ${label.toLowerCase()} experiment`;
    button.setAttribute('aria-label', neighbor ? `${label} experiment: ${neighbor.name}` : `${label} experiment`);
  }
  renderDots(sequence, index);
  layoutReaderChrome();
}

function stepReader(offset, focus = 'reader') {
  if (!active || !dialog.open) return;
  const sequence = readerSequence();
  const index = sequence.findIndex(concept => concept.key === active.key);
  if (index >= 0 && sequence[index + offset]) openReader(sequence[index + offset].key, 'original', { focus });
}

function focusActiveDot() {
  track.querySelector('[aria-pressed="true"]')?.focus({ preventScroll: true });
}

function openReader(key, revision = 'original', { history: mode = 'push', focus = 'reader' } = {}) {
  const concept = all.find(item => item.key === key) || graph?.ownerConcept(key) || graph?.aliasConcept(key);
  if (!concept) return false;
  if(graph){revisions[concept.key]=graph.revisionsFor(concept.graphItem);notes[concept.key]={...(concept.graphItem.review||{}),...(graph.pendingReview.get(concept.graphItem.id)||{})};key=concept.key;}
  const variantId = (revisions[key] || []).some(variant => variant.id === revision) ? revision : 'original';
  if (dialog.open && active?.key === key && activeVariantId === variantId) {
    commitHistory(readerState(), mode === 'push' ? 'none' : mode);
    if (focus === 'dot') focusActiveDot(); else if (focus === 'reader') focusReader();
    return true;
  }
  const opening = !dialog.open;
  setInfoOpen(false);
  active = concept;
  activeVariantId = variantId;
  if (opening) {
    setTheme(active.tone === 'night' ? 'night' : 'paper', false);
    setType(100, false);
    setReaderSize('fit');
    closeSizeMenu(false);
    setViewOpen(false, { focus: false });
    setNotesOpen(notesOpen, { focus: false });
  }
  renderRevisionOptions();
  renderReaderHeader();
  renderSizeControls();
  updateReaderNavigation();
  loadRevision({ focus: false });
  if (opening) dialog.showModal();
  layoutReaderChrome();
  commitHistory(readerState(), mode);
  updateMetadata();
  if (focus === 'dot') focusActiveDot();
  else if (focus === 'reader') focusReader();
  return true;
}

function closeReader({ history: mode = 'push' } = {}) {
  if (!active && !dialog.open) return;
  // Returning focus to the board must not move it: the board comes back exactly as it was left.
  const left = { ...view };
  if (graph?.feedback?.mode === 'reader') graph.feedback.close({restoreFocus:false});
  graph?.feedback?.closeVote?.({restoreFocus:false});
  closeSizeMenu(false);
  setViewOpen(false, { focus: false });
  hideTooltip();
  scrub = null;
  if (dialog.open) dialog.close();
  replaceFrame($('active-reader'), 'about:blank');
  active = null;
  if (graph) $('workspace-surfaces').hidden = true;
  commitHistory({ view: 'board', round: rounds[currentRound]?.id || null }, mode);
  if (board) updateMetadata();
  viewport.focus({ preventScroll: true });
  settleCushion();
  Object.assign(view, left);
  applyView();
}

// Escape closes the size panel first, then the notes panel while typing in it, otherwise returns to the board.
function handleEscape(event) {
  const keyEvent=event||{key:'Escape',defaultPrevented:false,isComposing:false,preventDefault(){},stopImmediatePropagation(){}};
  if(graph?.feedback?.consumeEscape(keyEvent))return true;
  if (!sizeMenu.hidden) { closeSizeMenu(true); return true; }
  if (viewControls.classList.contains('open')) { setViewOpen(false); return true; }
  if (notesOpen && $('notes-panel').contains(document.activeElement)) { setNotesOpen(false); return true; }
  closeReader();
  return true;
}

// ---- Dot track tooltip and scrubbing ----
function showTooltip(dot) {
  if (!dot) return;
  tooltip.textContent = dot.getAttribute('aria-label');
  tooltip.hidden = false;
  const footer = document.querySelector('.reader-footer').getBoundingClientRect();
  const bounds = track.getBoundingClientRect();
  const half = tooltip.offsetWidth / 2;
  tooltip.style.left = `${Math.max(12 + half, Math.min(innerWidth - 12 - half, bounds.left + bounds.width / 2))}px`;
  tooltip.style.bottom = `${innerHeight - footer.top + 8}px`;
}

function hideTooltip() { tooltip.hidden = true; }

function scrubTo(clientX) {
  const bounds = track.getBoundingClientRect();
  if (clientX < bounds.left + 18) track.scrollLeft -= 18;
  if (clientX > bounds.right - 18) track.scrollLeft += 18;
  let nearest = null;
  track.querySelectorAll('[data-dot]').forEach(dot => {
    const rect = dot.getBoundingClientRect();
    const distance = Math.abs(clientX - rect.left - rect.width / 2);
    if (!nearest || distance < nearest.distance) nearest = { dot, distance };
  });
  if (!nearest) return;
  track.querySelectorAll('.scrubbing').forEach(dot => dot.classList.remove('scrubbing'));
  nearest.dot.classList.add('scrubbing');
  scrub.key = nearest.dot.dataset.dot;
  showTooltip(nearest.dot);
}

function endScrub(commit) {
  if (!scrub) return;
  const { key } = scrub;
  scrub = null;
  track.querySelectorAll('.scrubbing').forEach(dot => dot.classList.remove('scrubbing'));
  hideTooltip();
  if (commit && key) openReader(key, 'original', { focus: 'dot' });
  void drainLiveUpdates().catch(()=>{});
}

// ---- Notes ----
function applyNotes() {
  document.querySelectorAll('[data-note]').forEach(element => { const value = notes[element.dataset.note]?.note || ''; if (element.value !== value) element.value = value; });
  document.querySelectorAll('[data-star]').forEach(element => { const starred = Boolean(notes[element.dataset.star]?.star); element.setAttribute('aria-pressed', String(starred)); if(!element.querySelector('svg'))element.textContent = starred ? '★' : '☆'; });
  syncReaderNotes();
}

function setSaveStatus(text, state) {
  $('save-status').textContent = text;
  $('save-status').dataset.state = state;
  $('reader-save-status').textContent = text;
}

function localNotes(key) {
  try {
    const value = JSON.parse(localStorage.getItem(key) || '{}');
    return value && typeof value === 'object' && !Array.isArray(value) ? value : {};
  } catch { return {}; }
}

function mergeNotes(base, incoming) {
  let changed = false;
  for (const [key, value] of Object.entries(incoming)) {
    if (!value || typeof value !== 'object') continue;
    if (!base[key] || (Number(value.updatedAt) || 0) > (Number(base[key].updatedAt) || 0)) { base[key] = value; changed = true; }
  }
  return changed;
}

async function flushNoteEdits(){
  clearTimeout(saveTimer);
  if(graph){if(await graph.saveReview(active&&!all.includes(active)?[...all,active]:all,notes)===false)throw Error('Notes remain in this browser. Try again.');return;}
  await persistLegacyNotes(saveSequence,JSON.stringify(notes));
}
function persistLegacyNotes(revision,body){
  const attempt=saveQueue.catch(()=>{}).then(async()=>{
    try{const response=await fetch(`${boardApi}/notes`,{method:'PUT',headers:{'Content-Type':'application/json','X-Tinka-Workspace':workspaceId},body});if(!response.ok)throw new Error('Notes not saved. Retry when the service is ready.');if(revision===saveSequence)setSaveStatus('Notes saved on this Mac','saved');}
    catch(error){if(revision===saveSequence)setSaveStatus('Saved in this browser · retry or export notes','local');throw error;}
  });saveQueue=attempt.catch(()=>{});return attempt;
}
function storeNotes() {
  if (graph) { graph.captureReview(active&&!all.includes(active)?[...all,active]:all,notes); clearTimeout(saveTimer); setSaveStatus('Saving item notes…','saving'); saveTimer=setTimeout(()=>graph.saveReview(active&&!all.includes(active)?[...all,active]:all,notes),350); return; }
  const revision = ++saveSequence;
  try { localStorage.setItem(notesKey, JSON.stringify(notes)); } catch {}
  setSaveStatus('Saving notes…', 'saving');
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    void persistLegacyNotes(revision,JSON.stringify(notes)).catch(()=>{});
  }, 350);
}

async function loadNotes() {
  if (graph) { notes = board.graphNotes || {}; applyNotes(); setSaveStatus(graph.pendingReview.size?'Unsaved feedback restored · retry when ready':'Item notes saved on this Mac',graph.pendingReview.size?'local':'saved'); return; }
  const backup = localNotes(notesKey);
  let server = {};
  let connected = false;
  try {
    const response = await fetch(`${boardApi}/notes`, { cache: 'no-store' });
    if (!response.ok) throw new Error('Notes unavailable');
    const value = await response.json();
    if (value && typeof value === 'object' && !Array.isArray(value)) server = value;
    connected = true;
  } catch {}
  notes = { ...server };
  const changed = mergeNotes(notes, backup);
  setSaveStatus(connected ? 'Notes saved on this Mac' : 'Browser notes · local service unavailable', connected ? 'saved' : 'local');
  applyNotes();
  if (changed) storeNotes();
}

// ---- Live build state ----
function decorateBuildCards() {
  document.querySelectorAll('.concept-card').forEach(card => {
    const badge = document.createElement('span'); badge.className = 'build-badge'; badge.textContent = 'Connecting'; card.querySelector('.card-title').append(badge);
    const overlay = document.createElement('div'); overlay.className = 'build-overlay'; overlay.hidden = true;
    const orbit = document.createElement('i'); orbit.className = 'build-orbit'; orbit.setAttribute('aria-hidden', 'true');
    overlay.append(orbit, document.createElement('strong'), document.createElement('span'));
    card.querySelector('.preview').append(overlay);
  });
}

function applyBoardSnapshotNow(snapshot) {
  if (graph) {
    graph.updateCovers(snapshot.boardCovers);
    const concepts = Object.fromEntries(all.map(c=>[c.key, {...(c.graphItem.build||{state:'ready'}), ...(snapshot.items?.[c.graphItem.id]||{})}]));
    liveSnapshot = {...snapshot,concepts};
    for (const concept of all) {
      const revision = concepts[concept.key]?.revision;
      if (!revision) continue;
      const card = [...world.querySelectorAll('.workspace-card')].find(c => c.dataset.key === concept.key);
      if (loadedPreviews.has(concept.key) && loadedPreviews.get(concept.key) !== revision) {
        const frame = card?.querySelector('.workspace-live-preview iframe');
        if (frame) {
          const source=new URL(frame.src,location.href);
          if(source.pathname==='/app/media.html'&&['panel','card'].includes(source.searchParams.get('mode'))&&source.searchParams.get('kind')==='markdown'){source.searchParams.set('v',revision);replaceFrame(frame,source.href);}
          else replaceFrame(frame, previewHref(concept, null, 'paper', 100, revision));
        }
        const pdf = card?.querySelector('.workspace-pdf-preview');
        if (pdf) {
          const source = new URL(pdf.src, location.href);
          source.searchParams.set('v', revision);
          pdf.src = source.href;
        }
        const image = card?.querySelector('.workspace-card-preview img');
        if (image) {
          const source = new URL(image.src, location.href);
          source.searchParams.set('v', revision);
          image.src = source.href;
        }
      }
      loadedPreviews.set(concept.key, revision);
    }
    const entry=concepts[active?.key]; if(active&&entry?.revision){ if(!activeRevision)activeRevision=entry.revision; $('reader-update').hidden=activeRevision===entry.revision; }
    $('live-status').textContent='Live · '+all.length+' items'; if(active)updateReaderNavigation(); return;
  }
  liveSnapshot = snapshot;
  const labels = { building: 'Building', reserved: 'Reserved', review: 'Ready to review', ready: 'Ready' };
  document.querySelectorAll('.concept-card').forEach(card => {
    const key = card.dataset.key;
    const entry = snapshot.concepts[key];
    if (!entry) return;
    const state = labels[entry.state] ? entry.state : 'reserved';
    card.dataset.buildState = state;
    card.dataset.liveRevision = entry.revision;
    const badge = card.querySelector('.build-badge'); badge.textContent = labels[state]; badge.title = entry.message || labels[state];
    const overlay = card.querySelector('.build-overlay'); overlay.hidden = !['building', 'reserved'].includes(state);
    overlay.querySelector('strong').textContent = state === 'building' ? 'Taking shape.' : 'A place for a new idea.';
    overlay.querySelector('span').textContent = entry.message || (state === 'building' ? 'This experiment is being built. Its preview will appear when it is ready to review.' : 'This slot is reserved for a future experiment.');
    card.querySelectorAll('[data-open]').forEach(button => button.disabled = state === 'reserved' || state === 'building');
    const frame = card.querySelector('iframe');
    if (state === 'ready' || state === 'review') {
      if (loadedPreviews.has(key) && loadedPreviews.get(key) !== entry.revision) {
        const concept = all.find(item => item.key === key);
        replaceFrame(frame, previewHref(concept, null, concept.tone === 'night' ? 'night' : 'paper', 100, entry.revision));
        card.classList.remove('just-landed');
        requestAnimationFrame(() => card.classList.add('just-landed'));
        setTimeout(() => card.classList.remove('just-landed'), 1800);
      }
      loadedPreviews.set(key, entry.revision);
    } else if (!loadedPreviews.has(key)) loadedPreviews.set(key, null);
  });
  const activeEntry = snapshot.concepts[activeSourceKey()];
  if (active && activeEntry) {
    if (!activeRevision) activeRevision = activeEntry.revision;
    $('reader-update').hidden = activeRevision === activeEntry.revision || !['ready', 'review'].includes(activeEntry.state);
    layoutReaderHeader();
  }
  const entries = all.map(concept => snapshot.concepts[concept.key]).filter(Boolean);
  const building = entries.filter(entry => entry.state === 'building').length;
  const review = entries.filter(entry => entry.state === 'review').length;
  const ready = entries.filter(entry => entry.state === 'ready').length;
  const parts = [building ? `${building} building` : null, review ? `${review} to review` : null, ready ? `${ready} ready` : null].filter(Boolean);
  $('live-status').textContent = `Live · ${parts.join(' · ') || 'Waiting for experiments'}`;
  if (active) updateReaderNavigation();
}

function acceptGraphData(fresh) {
  const activeKey=active?.key; board=fresh;rounds=fresh.rounds;revisions=fresh.revisions||{};notes=fresh.graphNotes||{};readRound();currentRound=Math.min(currentRound,Math.max(0,rounds.length-1));buildCanvas();
  if(activeKey){active=all.find(c=>c.key===activeKey)||active;renderRevisionOptions();renderReaderHeader();updateReaderNavigation();refreshReaderAnnotations({itemId:active.graphItem?.id});}
}

let pendingLiveSnapshot=null,liveManifestPending=false,liveDraining=false;
function liveBlocked(){
  const focused=document.activeElement;
  // Legacy board notes already preserve their exact value and selection during
  // keyed manifest reconciliation. Other editors retain deferred refresh.
  const legacyNote=!graph&&focused?.matches('textarea[data-note]')&&world.contains(focused);
  const editing=focused?.closest?.('textarea,input,select,[contenteditable]')&&!legacyNote;
  return !!(pointers.size||scrub||graph?.liveBlocked?.()||graph?.pointerGesture||graph?.decorationGesture||graph?.moveCommitting||graph?.client.pendingWrites||graph?.saving||editing||document.querySelector('dialog.workspace-dialog[open]'));
}
async function drainLiveUpdates(){
  if(liveDraining||liveBlocked())return;liveDraining=true;
  try{while(!liveBlocked()&&(liveManifestPending||pendingLiveSnapshot)){
    if(liveManifestPending){liveManifestPending=false;try{await refreshManifestNow();}catch(error){liveManifestPending=true;throw error;}}
    if(liveBlocked())break;
    if(pendingLiveSnapshot){const snapshot=pendingLiveSnapshot;pendingLiveSnapshot=null;applyBoardSnapshotNow(snapshot);}
  }}finally{liveDraining=false;}
}
function applyBoardSnapshot(snapshot){pendingLiveSnapshot=snapshot;return drainLiveUpdates();}
function refreshManifest(){liveManifestPending=true;return drainLiveUpdates();}
document.addEventListener('focusout',()=>queueMicrotask(()=>{void drainLiveUpdates().catch(()=>{});}));
document.addEventListener('close',()=>queueMicrotask(()=>{void drainLiveUpdates().catch(()=>{});}),true);
async function refreshManifestNow() {
  if(graph){await graph.refresh({saveReview:false});return;}
  const fresh = await fetchBoard();
  const selected = rounds[currentRound]?.id;
  const focused = document.activeElement;
  const noteKey = world.contains(focused) ? focused?.dataset.note : null;
  const selection = noteKey ? [focused.selectionStart, focused.selectionEnd] : null;
  board = fresh;
  rounds = fresh.rounds;
  revisions = fresh.revisions || {};
  readRound();
  currentRound = Math.max(0, rounds.findIndex(round => round.id === selected));
  buildCanvas();
  applyNotes();
  if (active) {
    active = all.find(concept => concept.key === active.key) || active;
    if (!currentVariant()) activeVariantId = 'original';
    renderRevisionOptions();
    renderReaderHeader();
    renderSizeControls();
    updateReaderNavigation();
  }
  if (noteKey) {
    const note = [...world.querySelectorAll('[data-note]')].find(element => element.dataset.note === noteKey);
    if (note) { note.focus({ preventScroll: true }); note.setSelectionRange(...selection); }
  }
  if (!dialog.open && document.activeElement === document.body) viewport.focus({ preventScroll: true });
  if (liveSnapshot) applyBoardSnapshot(liveSnapshot);
}

async function reloadCanvas() {
  clearTimeout(saveTimer);
  clearTimeout(shellReloadTimer);
  try { sessionStorage.setItem(viewKey, JSON.stringify({ zoom, x: view.x, y: view.y, resting, round: rounds[currentRound]?.id })); } catch {}
  if (graph) { clearTimeout(saveTimer); await graph.saveReview(active&&!all.includes(active)?[...all,active]:all,notes); }
  if (saveSequence && !graph) {
    try { await saveQueue; await fetch(`${boardApi}/notes`, { method: 'PUT', headers: { 'Content-Type': 'application/json', 'X-Tinka-Workspace': workspaceId }, body: JSON.stringify(notes) }); } catch {}
  }
  location.reload();
}

function scheduleShellReload() {
  $('live-refresh').hidden = false;
  // A new app shell is available. Only the explicit refresh action replaces the
  // page, preserving reader state, local drafts and active gestures.
}

function showError(message) {
  $('board-error').textContent = message;
  $('board-error').hidden = false;
  setSaveStatus('Board unavailable', 'error');
}

function setInfoOpen(open, { focus = false } = {}) {
  $('board-info').hidden = !open;
  $('board-info-toggle').setAttribute('aria-expanded', String(open));
  if (focus) (open ? $('board-info').querySelector('button,input,a') : $('board-info-toggle'))?.focus({ preventScroll: true });
}

// Controls are bound once; board content is replaced only after a manifest update.
document.addEventListener('pointerdown', event => {
  const remove = event.target.closest('[data-remove-experiment]');
  if (remove && event.button === 0) { event.preventDefault(); remove.focus({ preventScroll: true }); }
  if (!sizeMenu.hidden && !event.target.closest('.size-wrap')) closeSizeMenu(false);
  if (viewControls.classList.contains('open') && !event.target.closest('.reader-tools')) setViewOpen(false, { focus: false });
  if (!$('board-info').hidden && !event.target.closest('#board-info, #board-info-toggle')) setInfoOpen(false);
});
document.addEventListener('click', event => {
  const open = event.target.closest('[data-open]');
  const star = event.target.closest('[data-star]');
  const remove = event.target.closest('[data-remove-experiment]');
  if (remove && appConfig) {
    const concept = all.find(item => item.key === remove.dataset.removeExperiment);
    if (concept) openRemovalPrompt(appConfig, board, concept);
  }
  if (open && !open.disabled) {
    const concept = graph && (all.find(item => item.key === open.dataset.open) || graph.aliasConcept(open.dataset.open));
    if (concept?.graphItem.childBoardId && !concept.graphItem.content)
      graph.navigate(concept.graphItem.childBoardId);
    else openReader(open.dataset.open, open.dataset.revision);
  }
  if (star?.dataset.star) {
    const key = star.dataset.star;
    notes[key] = { ...notes[key], star: !notes[key]?.star, updatedAt: Date.now() };
    if(graph){const item=all.find(c=>c.key===key)?.graphItem||active?.graphItem;for(const c of all)if(c.graphItem.id===item?.id)notes[c.key]={...notes[c.key],star:notes[key].star};}
    applyNotes();
    storeNotes();
  }
});
document.addEventListener('input', event => {
  const target = event.target;
  const key = target.dataset.note || (target.id === 'reader-note' ? active?.key : null);
  if (!key) return;
  notes[key] = { ...notes[key], note: target.value, updatedAt: Date.now() };
  if(graph){const item=all.find(c=>c.key===key)?.graphItem||active?.graphItem;for(const c of all)if(c.graphItem.id===item?.id)notes[c.key]={...notes[c.key],note:target.value};}
  // The board card and the experiment view edit the same note.
  document.querySelectorAll('[data-note]').forEach(element => { if (element !== target && element.dataset.note === key) element.value = target.value; });
  syncReaderNotes();
  storeNotes();
});
bindCommitShortcut(world,{accept:event=>event.target.matches('textarea[data-note]'),commit:flushNoteEdits,onError:error=>setSaveStatus(error.message,'local')});
bindCommitShortcut($('reader-note'),{commit:flushNoteEdits,onError:error=>setSaveStatus(error.message,'local')});
$('reader-note').setAttribute('aria-keyshortcuts','Meta+Enter Control+Enter');
const readerNoteHint=document.createElement('small');readerNoteHint.className='workspace-submit-hint';readerNoteHint.textContent=`${commitShortcutLabel()} to save`; $('reader-note').after(readerNoteHint);
document.addEventListener('keydown', event => {
  if (event.key !== 'Escape' || event.defaultPrevented || event.isComposing || event.keyCode===229 || event.repeat || document.querySelector('dialog.workspace-dialog[open]')) return;
  if (dialog.open) { handleEscape(event); event.preventDefault(); return; }
  if (!$('board-info').hidden) { event.preventDefault(); setInfoOpen(false, { focus: true }); }
}, true);

slider.addEventListener('input', () => changeZoom(Number(slider.value) / 100));
$('fit').onclick = fitBoard;
$('board-info-toggle').onclick = () => setInfoOpen($('board-info').hidden, { focus: true });
$('close-reader').onclick = () => closeReader();
$('reader-board-link').addEventListener('click', event => {
  if (event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
  event.preventDefault();
  closeReader();
});
$('reader-previous').onclick = () => stepReader(-1);
$('reader-next').onclick = () => stepReader(1);
$('notes-toggle').onclick = () => setNotesOpen(!notesOpen);
$('notes-close').onclick = () => setNotesOpen(false);
$('reader-type').addEventListener('input', () => setType($('reader-type').value));
$('reader-fit').onclick = () => setReaderSize('fit');
$('reader-theme').onclick = () => setTheme(readerView.theme === 'night' ? 'paper' : 'night');
$('view-toggle').onclick = () => setViewOpen(!viewControls.classList.contains('open'));
$('size-trigger').onclick = () => (sizeMenu.hidden ? openSizeMenu() : closeSizeMenu());
sizeMenu.addEventListener('click', event => {
  const size = event.target.closest('[data-size]');
  const choice = event.target.closest('[data-revision-choice]');
  if (size) { setReaderSize(size.dataset.size); closeSizeMenu(); }
  if (choice && active) { closeSizeMenu(false); openReader(active.key, choice.dataset.revisionChoice); }
});
sizeMenu.addEventListener('keydown', event => {
  if (event.key !== 'ArrowDown' && event.key !== 'ArrowUp') return;
  const buttons = [...sizeMenu.querySelectorAll('button:not([hidden])')];
  const index = buttons.indexOf(document.activeElement);
  event.preventDefault();
  buttons[(index + (event.key === 'ArrowDown' ? 1 : -1) + buttons.length) % buttons.length].focus();
});
dialog.addEventListener('cancel', event => { event.preventDefault(); });
// A native close (not through closeReader) still returns to the board. The close event arrives
// asynchronously, so ignore it if the reader has been reopened in the meantime.
dialog.addEventListener('close', () => { if (active && !dialog.open) closeReader(); });
$('active-reader').addEventListener('load', () => {
  if (!dialog.open) return;
  // Key events inside a frame do not reach the surrounding dialog.
  try {
    $('active-reader').contentWindow.addEventListener('keydown', event => {
      if (event.key === 'Escape' && !event.defaultPrevented && !event.isComposing && event.keyCode!==229 && !event.repeat) { if(handleEscape(event))event.preventDefault(); }
    });
  } catch {} // Independent cross-origin previews own their keyboard handling.
});
const readerActions=new Set();
function readerContext(data,itemId){
  const frame=$('active-reader'),source=frame.contentWindow;
  const selectionId=typeof data.selectionId==='string'&&data.selectionId.length<=80?data.selectionId:undefined;
  const options={host:dialog.querySelector('.reader-area'),mode:'reader',selectionId,returnFocus:()=>{
    if(dialog.open&&active?.graphItem?.id===itemId&&activeVariantId==='original'&&frame.contentWindow===source)
      source.postMessage({type:'tinka-reader-focus',selectionId},location.origin);
  }};
  const r=data.selectionRect;
  if(r&&typeof r==='object'&&!Array.isArray(r)&&Object.keys(r).length===4&&['top','bottom','left','right'].every(key=>Number.isFinite(r[key])&&Math.abs(r[key])<=100000)&&r.bottom>=r.top&&r.right>=r.left){
    const box=frame.getBoundingClientRect();options.selectionRect={top:Math.max(box.top,Math.min(box.bottom,box.top+r.top)),bottom:Math.max(box.top,Math.min(box.bottom,box.top+r.bottom)),left:Math.max(box.left,Math.min(box.right,box.left+r.left)),right:Math.max(box.left,Math.min(box.right,box.left+r.right))};
  }
  return options;
}
function refreshReaderAnnotations(detail={}){
  if(dialog.open&&activeVariantId==='original'&&active?.graphItem?.id===detail.itemId)
    $('active-reader').contentWindow?.postMessage({type:'tinka-annotations-refresh'},location.origin);
}
function wireReaderReview(){
  if(graph?.feedback&&!graph.feedback.canvasReviewBound){graph.feedback.canvasReviewBound=true;graph.feedback.onCommitted=refreshReaderAnnotations;}
}
window.addEventListener('message', event => {
  if(event.origin!==location.origin||event.source!==$('active-reader').contentWindow)return;
  if(event.data?.type==='reader-close'){handleEscape();return;}
  const item=active?.graphItem,data=event.data;
  if(!dialog.open||!graph||!item||activeVariantId!=='original'||data?.itemId!==item.id||item.content?.kind!=='markdown'||!item.content.resource||item.content.url)return;
  wireReaderReview();const options=readerContext(data,item.id);
  if(data.type==='tinka-selection-context'){graph.feedback.updateReaderContext({selectionId:options.selectionId,selectionRect:options.selectionRect});return;}
  if(data.type==='tinka-comment-selection'&&validTextAnchor(data.anchor)&&/^sha256:[a-f0-9]{64}$/.test(data.anchor.sourceRevision||'')){
    graph.feedback.commentOnText(item.id,data.anchor,options);
  }else if(data.type==='tinka-open-comment'&&typeof data.threadId==='string'&&/^[a-zA-Z0-9][a-zA-Z0-9_-]{0,127}$/.test(data.threadId)){
    graph.feedback.open({...options,itemId:item.id,threadId:data.threadId});
  }else if((data.type==='tinka-highlight-selection'&&validTextAnchor(data.anchor)&&/^sha256:[a-f0-9]{64}$/.test(data.anchor.sourceRevision||''))||(data.type==='tinka-remove-highlight'&&typeof data.highlightId==='string'&&/^[a-zA-Z0-9][a-zA-Z0-9_-]{0,127}$/.test(data.highlightId))){
    const frame=event.source,key=JSON.stringify([item.id,data.type,data.selectionId||data.highlightId||data.anchor]);if(readerActions.has(key))return;readerActions.add(key);
    const result=(ok,error)=>{if(dialog.open&&active?.graphItem?.id===item.id&&$('active-reader').contentWindow===frame)frame.postMessage({type:'tinka-annotation-result',selectionId:data.selectionId,ok,...(error?{message:error.message}: {})},location.origin);};
    const action=data.type==='tinka-highlight-selection'?graph.feedback.highlightOnText(item.id,data.anchor):graph.feedback.removeHighlight(item.id,data.highlightId);
    Promise.resolve(action).then(()=>result(true),error=>result(false,error)).finally(()=>readerActions.delete(key));
  }
});
$('export').onclick = () => {
  const blob = new Blob([JSON.stringify({ board: boardId, title: board?.title || 'Board', exportedAt: new Date().toISOString(), notes }, null, 2)], { type: 'application/json' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = `${boardId}-notes.json`;
  link.click();
  setTimeout(() => URL.revokeObjectURL(link.href), 1000);
};

// Dot track: click or drag to choose, hover or focus to read a title, arrow keys to step.
track.addEventListener('pointerdown', event => {
  if (event.button !== 0 || !track.querySelector('[data-dot]')) return;
  event.preventDefault();
  scrub = { key: null, pointerId: event.pointerId };
  try { track.setPointerCapture(event.pointerId); } catch {}
  scrubTo(event.clientX);
});
track.addEventListener('pointermove', event => { if (scrub?.pointerId === event.pointerId) scrubTo(event.clientX); });
track.addEventListener('pointerup', event => {
  if (scrub?.pointerId !== event.pointerId) return;
  scrubTo(event.clientX);
  try { track.releasePointerCapture(event.pointerId); } catch {}
  endScrub(true);
});
track.addEventListener('pointercancel', () => endScrub(false));
track.addEventListener('scroll', updateTrackFade, { passive: true });
track.addEventListener('click', event => {
  const dot = event.target.closest('[data-dot]');
  if (dot && event.detail === 0) openReader(dot.dataset.dot, 'original', { focus: 'dot' });
});
track.addEventListener('keydown', event => {
  if (!event.target.matches('[data-dot]')) return;
  const sequence = readerSequence();
  const index = sequence.findIndex(concept => concept.key === active?.key);
  const next = { ArrowRight: index + 1, ArrowLeft: index - 1, Home: 0, End: sequence.length - 1 }[event.key];
  if (next === undefined) return;
  event.preventDefault();
  if (sequence[next]) openReader(sequence[next].key, 'original', { focus: 'dot' });
});
track.addEventListener('pointerover', event => { const dot = event.target.closest('[data-dot]'); if (dot && !scrub) showTooltip(dot); });
track.addEventListener('pointerout', event => { if (!scrub && event.target.closest('[data-dot]') && !track.contains(event.relatedTarget)) hideTooltip(); });
track.addEventListener('focusin', event => { if (event.target.matches('[data-dot]:focus-visible')) showTooltip(event.target); });
track.addEventListener('focusout', () => { if (!scrub) hideTooltip(); });

// Legacy canvas: background drag pans. Graph Canvas uses ordinary scrolling; both keep two-finger pinch zoom.
const pointers = new Map();
let pan = null;
let pinch = null;
viewport.addEventListener('pointerdown', event => {
  if (graph?.mode === 'grid') return;
  if (graph && (event.pointerType !== 'touch' || (event.target.closest('button') && !event.target.closest('.workspace-preview-launch')))) return;
  if (event.pointerType === 'mouse' && event.button !== 0) return;
  if (event.target.closest('textarea,input,select,a')) return;
  stopGlide();
  pointers.set(event.pointerId, { x: event.clientX, y: event.clientY, canPan: !graph || !event.target.closest('.workspace-card') });
  if (pointers.size === 1) {
    pan = graph && event.target.closest('.workspace-card') ? null : { id: event.pointerId, x: event.clientX, y: event.clientY, left: view.x, top: view.y, active: false };
    pinch = null;
  } else if (pointers.size === 2) {
    const [a, b] = [...pointers.values()];
    const [mx, my] = viewportPoint((a.x + b.x) / 2, (a.y + b.y) / 2);
    pinch = { distance: Math.hypot(a.x - b.x, a.y - b.y) || 1, zoom, x: (mx - view.x) / zoom, y: (my - view.y) / zoom };
    pan = null;
    viewport.classList.add('panning');
  }
});
viewport.addEventListener('pointermove', event => {
  if (!pointers.has(event.pointerId)) return;
  pointers.set(event.pointerId, { ...pointers.get(event.pointerId), x: event.clientX, y: event.clientY });
  if (pinch && pointers.size >= 2) {
    const [a, b] = [...pointers.values()];
    const [mx, my] = viewportPoint((a.x + b.x) / 2, (a.y + b.y) / 2);
    zoom = clampZoom(pinch.zoom * (Math.hypot(a.x - b.x, a.y - b.y) || 1) / pinch.distance);
    moveView(mx - pinch.x * zoom, my - pinch.y * zoom);
    return;
  }
  if (!pan || pan.id !== event.pointerId) return;
  const dx = event.clientX - pan.x;
  const dy = event.clientY - pan.y;
  if (!pan.active && Math.hypot(dx, dy) > 4) {
    pan.active = true;
    viewport.classList.add('panning');
    try { viewport.setPointerCapture(event.pointerId); } catch {}
  }
  if (pan.active) moveView(pan.left + dx, pan.top + dy);
});
function endPointer(event) {
  if (!pointers.has(event.pointerId)) return;
  pointers.delete(event.pointerId);
  if (pointers.size < 2) pinch = null;
  if (pointers.size === 1) {
    const [id, point] = [...pointers.entries()][0];
    pan = graph && !point.canPan ? null : { id, x: point.x, y: point.y, left: view.x, top: view.y, active: true };
  } else if (!pointers.size) { pan = null; viewport.classList.remove('panning'); }
  void drainLiveUpdates().catch(()=>{});
}
viewport.addEventListener('pointerup', endPointer);
viewport.addEventListener('pointercancel', endPointer);
// A note field with more to scroll keeps its own wheel scrolling.
function scrollsItself(target, dy) {
  const field = target.closest?.('textarea,.workspace-card-copy');
  if (!field || !dy) return false;
  return dy > 0 ? field.scrollTop + field.clientHeight < field.scrollHeight - 1 : field.scrollTop > 0;
}
// Control/⌘-scroll (and trackpad pinch) zooms about the pointer; any other scroll pans.
viewport.addEventListener('wheel', event => {
  if (graph?.mode === 'grid') return;
  if (event.ctrlKey || event.metaKey) {
    event.preventDefault();
    const delta = Math.max(-60, Math.min(60, event.deltaMode === 1 ? event.deltaY * 16 : event.deltaY));
    changeZoom(zoom * Math.exp(-delta * .005), ...viewportPoint(event.clientX, event.clientY));
    return;
  }
  const unit = event.deltaMode === 1 ? 16 : event.deltaMode === 2 ? viewport.clientHeight : 1;
  let dx = event.deltaX * unit;
  let dy = event.deltaY * unit;
  if (event.shiftKey && !dx) [dx, dy] = [dy, 0];
  if (scrollsItself(event.target, dy)) return;
  event.preventDefault();
  moveView(view.x - dx, view.y - dy);
}, { passive: false });
let gestureZoom = zoom;
viewport.addEventListener('gesturestart', event => { event.preventDefault(); gestureZoom = zoom; });
viewport.addEventListener('gesturechange', event => { event.preventDefault(); changeZoom(gestureZoom * event.scale, ...viewportPoint(event.clientX, event.clientY)); });
viewport.addEventListener('gestureend', event => event.preventDefault());
// Keys pan as scrolling did: arrows, Page Up/Down and Space (on the canvas itself), Home and End for the first and
// last explorations. + and − zoom about the centre.
viewport.addEventListener('keydown', event => {
  if (graph?.mode === 'grid') return;
  if (event.defaultPrevented || event.metaKey || event.ctrlKey || event.altKey) return;
  if (event.target.closest('textarea,input,select,[contenteditable]')) return;
  const onCanvas = event.target === viewport;
  const page = viewport.clientHeight * .875;
  const key = event.key === ' ' && onCanvas ? (event.shiftKey ? 'PageUp' : 'PageDown') : event.key;
  const step = { ArrowLeft: [80, 0], ArrowRight: [-80, 0], ArrowUp: [0, 80], ArrowDown: [0, -80], PageUp: [0, page], PageDown: [0, -page] }[key];
  if (onCanvas && (key === '+' || key === '=')) changeZoom(zoom * 1.15);
  else if (onCanvas && (key === '-' || key === '_')) changeZoom(zoom / 1.15);
  else if (key.startsWith('Arrow') && step) moveView(view.x + step[0], view.y + step[1]);
  else if (step) { const from = glideTarget || view; glideTo({ x: from.x + step[0], y: from.y + step[1] }, { track: true }); }
  else if ((key === 'Home' || key === 'End') && rounds.length) { currentRound = key === 'Home' ? 0 : rounds.length - 1; renderNav(); glideTo(restingView()); }
  else return;
  event.preventDefault();
});
new ResizeObserver(() => {
  if ($('reader-window').style.width && readerView.size !== 'custom') readerView.size = 'custom';
  // A new size label can change the footer layout, which resizes this window; lay out on the next frame to avoid a resize loop.
  if (dialog.open) { renderSizeControls(false); requestAnimationFrame(layoutReaderFooter); }
}).observe($('reader-window'));
new ResizeObserver(() => { if (resting) rest(); else applyView(); }).observe(viewport);
// The dialog fills the window, so this fires on window resizes but never because the footer re-laid itself out.
new ResizeObserver(layoutReaderChrome).observe(dialog);
// The browser scrolls the canvas to reveal keyboard focus or a find-in-page match; carry that over as a pan.
// A press on a card control never moves the board.
viewport.style.setProperty('--cushion', `${CUSHION}px`);
settleCushion();
viewport.addEventListener('scroll', () => {
  if (graph?.mode === 'grid') return;
  const dx = viewport.scrollLeft - CUSHION;
  const dy = viewport.scrollTop - CUSHION;
  if (!dx && !dy) return;
  settleCushion();
  if (!pointers.size) moveView(view.x - dx, view.y - dy);
}, { passive: true });
window.addEventListener('popstate', route);
// Clicking into the experiment frame never reaches this document; close the popover when focus leaves it.
window.addEventListener('blur', () => { closeSizeMenu(false); setViewOpen(false, { focus: false }); if (!scrub) hideTooltip(); });
window.addEventListener('hashchange', route);
$('live-refresh').onclick = reloadCanvas;
$('reader-update').onclick = () => loadRevision();
if ('scrollRestoration' in history) history.scrollRestoration = 'manual';

if (!boardId) showError('This board address is invalid. Return to Boards and open a board from there.');
else {
  try {
    await loadAppTitle();
    board = await fetchBoard();
    rounds = board.rounds;
    revisions = board.revisions || {};
    readRound();
    if (graph) { graph.mount(); if(graph.mode==='grid'){viewport.scrollLeft=0;viewport.scrollTop=0;}else settleCushion(); }
    else { const b=document.createElement('button');b.type='button';b.textContent='Enable organization…';b.onclick=()=>enableOrganization(appConfig);document.querySelector('.info-actions').append(b); }
    currentRound = Math.max(0, rounds.length - 1);
    buildCanvas();
    await loadNotes();
    setTheme(readerView.theme, false);
    setType(readerView.type, false);
    const requested = parseHash();
    if (requested.view === 'experiment') {
      const concept = all.find(item => item.key === requested.key) || graph?.ownerConcept(requested.key) || graph?.aliasConcept(requested.key);
      currentRound = concept?.row || 0;
      renderNav();
      jump(concept.key);
      openReader(requested.key, requested.revision || 'original', { history: 'replace' });
    } else {
      if (requested.invalid) commitHistory({ view: 'board', round: null }, 'replace');
      const index = rounds.findIndex(round => round.id === requested.round);
      if (index >= 0) currentRound = index;
      renderNav();
      rest();
    }
    routedHash = location.hash;
    try {
      const saved = JSON.parse(sessionStorage.getItem(viewKey) || 'null');
      sessionStorage.removeItem(viewKey);
      if (saved && Number.isFinite(saved.zoom)) {
        zoom = clampZoom(saved.zoom);
        currentRound = Math.max(0, rounds.findIndex(round => round.id === saved.round));
        renderNav();
        // A view saved by an earlier version (scroll offsets) falls back to the round's resting place.
        if (saved.resting || !Number.isFinite(saved.x) || !Number.isFinite(saved.y)) rest();
        else { resting = false; Object.assign(view, { x: saved.x, y: saved.y }); applyView(); }
      }
    } catch {}
    if (!dialog.open && document.activeElement === document.body) viewport.focus({ preventScroll: true });
    $('live-status').classList.add('live-indicator');
    watchBoard(boardId, {
      config:appConfig,
      onSnapshot: applyBoardSnapshot,
      onManifestChange: refreshManifest,
      onShellChange: scheduleShellReload,
      onConnection: connected => { const label = $('live-status'); label.dataset.connection = connected ? 'live' : 'offline'; if (!connected) label.textContent = 'Reconnecting to this Mac…'; else if (liveSnapshot && label.textContent.startsWith('Reconnecting')) applyBoardSnapshot(liveSnapshot); },
    });
  } catch (error) { showError(error.message || 'This board could not be loaded.'); }
}
